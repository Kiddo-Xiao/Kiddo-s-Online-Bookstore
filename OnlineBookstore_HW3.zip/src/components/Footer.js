import React from 'react';
import { Row, Col } from 'antd';
// import logo from '../assets/logo.svg';
// import logoFont from '../assets/logo-name.svg';
// import {UserAvatar} from "./UserAvatar";

export class Footer extends React.Component {

    render() {
        return(
            <div className="footer">
                <p>Developer: Kiddo</p>
                <p>e-mail: kiddo_Xiao@sjtu.edu.cn</p>
                <p>Development Time Interval: 20220302 - ???</p>
            </div>
        )
    }

}