import React from 'react';
import { Router, Route, 
    Switch,
    Redirect,
    Link} from 'react-router-dom';
// import {IndexRoute} from 'react-router'
// import PrivateRoute from './PrivateRoute'
// import LoginRoute from  './LoginRoute'
import HomeView from "./view/HomeView";
import LoginView from './view/LoginView';
import CartView from "./view/CartView";
import BookView from "./view/BookView";
import {history} from "./utils/history";



class BasicRoute extends React.Component{
    constructor(props) {
        super(props);
        ///*用于网站前进后退的记录（栈）*/
        // history.listen((location, action) => {
        //     // clear alert on location change
        //     console.log(location,action);
        // });
    }

    render(){
        return(
            //可用动态↓
            history.push('/cart'),
            // history.go(),
            <Router history={history}>
                {/*<ul>*/}
                {/*    <li>*/}
                {/*        <Link to="/LoginView">To LoginView</Link>*/}
                {/*    </li>*/}
                {/*</ul>*/}
                <Route  exact path="/login" component={LoginView}/>
                <Route  exact path="/home" component={HomeView} />
                <Route  exact path="/cart" component={CartView} />
                <Route  exact path="/book" component={BookView} />
                {/*<Route  exact path="/order" component={OrderView} />*/}
             </Router>


            // 静态版本↓
            // <div>
            //     {/*<LoginView exact path="/login" component={LoginView} />*/}
            //     <HomeView exact path="/" component={HomeView} />
            // </div>

            //老师版本↓
            // <Switch>
            //     前端实现判断登录的较复杂代码↓
            //     <PrivateRoute exact path="/" component={HomeView} />
            //     <LoginRoute exact path="/login" component={LoginView} />
            //     <PrivateRoute exact path="/bookDetails" component={BookView} />
            //     <Redirect from="/*" to="/" /> 所有重定向都导向login
            // </Switch>
        );
    }
}
export default BasicRoute;